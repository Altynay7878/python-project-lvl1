

def greeting():
    print('Welcome to the Brain Games!')


def welcome_user():
    name = ('May I have you name? ')
    return name
